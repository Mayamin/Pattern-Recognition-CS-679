#include <iostream>
// #include <stdlib>
// #include <vector>
// #include <Eigen/Core>
// #include <Eigen/Dense>

using namespace std;

//Mayamin data generation part 2
// returns 2D points of data
//vector<vector<float>> generate_data(vector<VectorXd> mean, vector<MatrixXd> covariance_matrices);

//Tyler parts 1, 3 , 4


int main ()
{
	cout << "Hello world!" << endl;
	// std::cout << "Hello World!";
	return 0;
}